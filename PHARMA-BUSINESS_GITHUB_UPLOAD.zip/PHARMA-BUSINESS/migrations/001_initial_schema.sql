-- Pharma Business initial PostgreSQL schema (Supabase-compatible starting point)
-- Review and adapt before applying to a production database.
create extension if not exists pgcrypto;

create table if not exists pharmacies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);
create table if not exists pharmacy_members (
  pharmacy_id uuid not null references pharmacies(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin','pharmacist','cashier','viewer')),
  created_at timestamptz not null default now(),
  primary key (pharmacy_id,user_id)
);
create table if not exists branches (
  id uuid primary key default gen_random_uuid(),
  pharmacy_id uuid not null references pharmacies(id) on delete cascade,
  name text not null,
  address text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists suppliers (
  id uuid primary key default gen_random_uuid(),
  pharmacy_id uuid not null references pharmacies(id) on delete cascade,
  name text not null,
  phone text,
  tax_id text,
  notes text,
  created_at timestamptz not null default now()
);
create table if not exists customers (
  id uuid primary key default gen_random_uuid(),
  pharmacy_id uuid not null references pharmacies(id) on delete cascade,
  name text not null,
  phone text,
  notes text,
  created_at timestamptz not null default now()
);
create table if not exists medicines (
  id uuid primary key default gen_random_uuid(),
  pharmacy_id uuid not null references pharmacies(id) on delete cascade,
  sku text,
  barcode text,
  name text not null,
  generic_name text,
  category text,
  manufacturer text,
  dosage_form text,
  strength text,
  unit text not null default 'dona',
  purchase_price numeric(14,2) not null default 0 check (purchase_price >= 0),
  sale_price numeric(14,2) not null default 0 check (sale_price >= 0),
  min_stock numeric(14,3) not null default 0 check (min_stock >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (pharmacy_id, sku)
);
create table if not exists stock_batches (
  id uuid primary key default gen_random_uuid(),
  pharmacy_id uuid not null references pharmacies(id) on delete cascade,
  branch_id uuid not null references branches(id),
  medicine_id uuid not null references medicines(id),
  supplier_id uuid references suppliers(id),
  batch_number text,
  expiry_date date,
  quantity numeric(14,3) not null default 0 check (quantity >= 0),
  purchase_price numeric(14,2) not null default 0 check (purchase_price >= 0),
  received_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create table if not exists sales (
  id uuid primary key default gen_random_uuid(),
  pharmacy_id uuid not null references pharmacies(id) on delete cascade,
  branch_id uuid not null references branches(id),
  customer_id uuid references customers(id),
  receipt_number text,
  status text not null default 'completed' check (status in ('draft','completed','voided','refunded')),
  subtotal numeric(14,2) not null default 0,
  discount numeric(14,2) not null default 0,
  total numeric(14,2) not null default 0,
  payment_method text,
  cashier_id uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create table if not exists sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references sales(id) on delete cascade,
  medicine_id uuid not null references medicines(id),
  batch_id uuid references stock_batches(id),
  quantity numeric(14,3) not null check (quantity > 0),
  unit_price numeric(14,2) not null check (unit_price >= 0),
  line_discount numeric(14,2) not null default 0,
  line_total numeric(14,2) not null
);
create table if not exists purchase_receipts (
  id uuid primary key default gen_random_uuid(),
  pharmacy_id uuid not null references pharmacies(id) on delete cascade,
  branch_id uuid not null references branches(id),
  supplier_id uuid references suppliers(id),
  invoice_number text,
  total numeric(14,2) not null default 0,
  received_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create table if not exists stock_movements (
  id uuid primary key default gen_random_uuid(),
  pharmacy_id uuid not null references pharmacies(id) on delete cascade,
  branch_id uuid not null references branches(id),
  medicine_id uuid not null references medicines(id),
  batch_id uuid references stock_batches(id),
  movement_type text not null check (movement_type in ('purchase','sale','return','adjustment','transfer_in','transfer_out','write_off')),
  quantity_delta numeric(14,3) not null,
  reference_id uuid,
  note text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create table if not exists audit_log (
  id uuid primary key default gen_random_uuid(),
  pharmacy_id uuid not null references pharmacies(id) on delete cascade,
  actor_id uuid references auth.users(id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists idx_medicines_name on medicines(pharmacy_id,name);
create index if not exists idx_batches_expiry on stock_batches(pharmacy_id,expiry_date);
create index if not exists idx_sales_created on sales(pharmacy_id,created_at desc);
create index if not exists idx_stock_movements_medicine on stock_movements(medicine_id,created_at desc);

-- IMPORTANT: Enable RLS and add pharmacy-membership policies before production use.
-- Never expose a Supabase service-role key in browser JavaScript.
